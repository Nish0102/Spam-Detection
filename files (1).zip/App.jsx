import React, { useState, useRef } from 'react'
import { Shield, ChevronRight, Terminal, BarChart2, History, AlertTriangle } from 'lucide-react'
import { useSpam } from './hooks/useSpam'
import VerdictPanel     from './components/VerdictPanel'
import HighlightPanel   from './components/HighlightPanel'
import ModelComparison  from './components/ModelComparison'
import HistoryPanel     from './components/HistoryPanel'

const EXAMPLES = [
  { label:'Lottery scam',  text:"CONGRATULATIONS! You've WON $1,000,000 in our lottery! Click here NOW to claim your FREE prize before it expires! Limited time offer — ACT NOW!!!" },
  { label:'Phishing',      text:"Urgent: Your bank account has been suspended. Verify your password and account details immediately at secure-bank-verify.com to avoid permanent closure." },
  { label:'Work email',    text:"Hi Sarah, please find the attached Q3 report for your review. Could we schedule a meeting this week to discuss the project updates? Thanks, James" },
  { label:'Pill spam',     text:"Buy cheap Viagra pills online! No prescription needed! 100% satisfaction guaranteed! Best price! Order now and get FREE shipping on all orders!" },
  { label:'Normal email',  text:"Dear team, the sprint planning meeting is scheduled for Thursday at 10am. Please review the backlog tickets before joining. Regards, Alex" },
]

const TABS = [
  { id:'explain',  icon: Terminal,  label:'Explain'   },
  { id:'models',   icon: BarChart2, label:'Models'    },
  { id:'history',  icon: History,   label:'History'   },
]

export default function App() {
  const [input, setInput]     = useState('')
  const [tab, setTab]         = useState('explain')
  const textareaRef           = useRef(null)
  const { result, loading, error, history, selectedModel, setModel, analyze, batchAnalyze } = useSpam()

  const handleAnalyze = () => {
    if (!input.trim() || loading) return
    analyze(input)
  }

  const handleExample = (text) => {
    setInput(text)
    analyze(text)
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) handleAnalyze()
  }

  return (
    <div style={{
      minHeight:'100vh', background:'var(--bg)',
      display:'flex', flexDirection:'column',
      position:'relative', overflow:'hidden'
    }}>
      {/* Scanline effect */}
      <div style={{
        position:'fixed', top:0, left:0, right:0, bottom:0, pointerEvents:'none', zIndex:0,
        backgroundImage:'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)',
      }}/>

      {/* Header */}
      <header style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        padding:'16px 28px',
        borderBottom:'1px solid var(--border)',
        background:'var(--bg2)', position:'relative', zIndex:1
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{
            width:36, height:36, borderRadius:8, background:'var(--red-dim)',
            border:'1px solid rgba(255,71,87,0.3)',
            display:'flex', alignItems:'center', justifyContent:'center'
          }}>
            <Shield size={18} color="var(--red)" strokeWidth={1.5}/>
          </div>
          <div>
            <div style={{ fontFamily:'var(--sans)', fontSize:18, fontWeight:800, letterSpacing:'0.04em', color:'var(--text)' }}>
              SpamShield
            </div>
            <div style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)', letterSpacing:'0.1em' }}>
              AI-POWERED SPAM DETECTION
            </div>
          </div>
        </div>

        {/* Model selector */}
        <div style={{ display:'flex', gap:6 }}>
          {[
            { key:'naive_bayes', label:'NB' },
            { key:'rule_based',  label:'Rules' },
            { key:'ensemble',    label:'Ensemble' },
          ].map(m => (
            <button
              key={m.key}
              onClick={() => setModel(m.key)}
              style={{
                fontFamily:'var(--mono)', fontSize:11, fontWeight:500,
                padding:'5px 12px', borderRadius:4,
                border: selectedModel === m.key ? '1px solid var(--blue)' : '1px solid var(--border)',
                background: selectedModel === m.key ? 'var(--blue-dim)' : 'transparent',
                color: selectedModel === m.key ? 'var(--blue)' : 'var(--text-dim)',
                cursor:'pointer', transition:'all 0.15s ease',
                letterSpacing:'0.04em'
              }}
            >{m.label}</button>
          ))}
        </div>
      </header>

      {/* Main content */}
      <div style={{
        flex:1, display:'grid', gridTemplateColumns:'1fr 380px',
        gap:0, maxWidth:1200, width:'100%', margin:'0 auto',
        padding:'0', position:'relative', zIndex:1
      }}>
        {/* Left: input + result */}
        <div style={{ padding:'24px', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', gap:20 }}>

          {/* Input area */}
          <div>
            <div style={{
              fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)',
              letterSpacing:'0.1em', marginBottom:8, display:'flex', alignItems:'center', gap:6
            }}>
              <Terminal size={11}/> PASTE MESSAGE TO SCAN
            </div>
            <div style={{
              border:'1px solid var(--border)', borderRadius:'var(--radius-lg)',
              background:'var(--bg2)', overflow:'hidden',
              transition:'border-color 0.2s ease',
            }}
              onFocusCapture={e => e.currentTarget.style.borderColor = 'var(--blue)'}
              onBlurCapture={e => e.currentTarget.style.borderColor = 'var(--border)'}
            >
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Paste an email, SMS, or any message here…"
                rows={6}
                style={{
                  width:'100%', border:'none', outline:'none',
                  background:'transparent', resize:'vertical',
                  fontFamily:'var(--mono)', fontSize:13, lineHeight:1.7,
                  color:'var(--text)', padding:'14px 16px',
                  minHeight:120,
                  '::placeholder': { color:'var(--text-mute)' }
                }}
              />
              <div style={{
                display:'flex', alignItems:'center', justifyContent:'space-between',
                padding:'8px 12px', borderTop:'1px solid var(--border)',
                background:'var(--bg3)'
              }}>
                <span style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)' }}>
                  {input.length} chars · Ctrl+Enter to scan
                </span>
                <button
                  onClick={handleAnalyze}
                  disabled={!input.trim() || loading}
                  style={{
                    display:'flex', alignItems:'center', gap:6,
                    fontFamily:'var(--mono)', fontSize:12, fontWeight:600,
                    padding:'7px 16px', borderRadius:4, border:'none',
                    background: input.trim() && !loading ? 'var(--red)' : 'var(--bg)',
                    color: input.trim() && !loading ? '#fff' : 'var(--text-mute)',
                    cursor: input.trim() && !loading ? 'pointer' : 'default',
                    transition:'all 0.15s ease', letterSpacing:'0.06em'
                  }}
                >
                  {loading ? 'SCANNING…' : <>SCAN <ChevronRight size={13}/></>}
                </button>
              </div>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div style={{
              display:'flex', gap:8, alignItems:'center',
              background:'var(--red-dim)', border:'1px solid rgba(255,71,87,0.3)',
              borderRadius:'var(--radius)', padding:'10px 14px',
              fontFamily:'var(--mono)', fontSize:12, color:'var(--red)'
            }}>
              <AlertTriangle size={13}/> {error}
            </div>
          )}

          {/* Quick examples */}
          <div>
            <div style={{
              fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)',
              letterSpacing:'0.1em', marginBottom:8
            }}>QUICK EXAMPLES</div>
            <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
              {EXAMPLES.map(ex => (
                <button
                  key={ex.label}
                  onClick={() => handleExample(ex.text)}
                  style={{
                    fontFamily:'var(--mono)', fontSize:11, padding:'5px 10px',
                    border:'1px solid var(--border)', borderRadius:4,
                    background:'var(--bg3)', color:'var(--text-dim)',
                    cursor:'pointer', transition:'all 0.15s ease', letterSpacing:'0.03em'
                  }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor='var(--blue)'; e.currentTarget.style.color='var(--blue)' }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.color='var(--text-dim)' }}
                >
                  {ex.label}
                </button>
              ))}
            </div>
          </div>

          {/* Verdict */}
          <VerdictPanel result={result} loading={loading}/>
        </div>

        {/* Right: tabs panel */}
        <div style={{ display:'flex', flexDirection:'column', height:'100vh', overflow:'hidden' }}>
          {/* Tab bar */}
          <div style={{
            display:'flex', borderBottom:'1px solid var(--border)',
            background:'var(--bg2)', flexShrink:0
          }}>
            {TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                style={{
                  flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6,
                  padding:'13px 8px', border:'none', borderBottom: tab===t.id ? '2px solid var(--red)' : '2px solid transparent',
                  background:'transparent', cursor:'pointer',
                  fontFamily:'var(--mono)', fontSize:11, letterSpacing:'0.06em', fontWeight:600,
                  color: tab===t.id ? 'var(--text)' : 'var(--text-mute)',
                  transition:'all 0.15s ease'
                }}
              >
                <t.icon size={12}/> {t.label.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div style={{ flex:1, overflowY:'auto', padding:'20px 18px' }}>
            {tab === 'explain' && (
              <HighlightPanel highlights={result?.highlights} text={input}/>
            )}
            {tab === 'models' && (
              <ModelComparison allModels={result?.all_models} currentText={input}/>
            )}
            {tab === 'history' && (
              <HistoryPanel history={history} onReplay={t => { setInput(t); analyze(t) }}/>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

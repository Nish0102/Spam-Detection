import React from 'react'
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip } from 'recharts'

const MODEL_COLORS = {
  naive_bayes: 'var(--blue)',
  rule_based:  'var(--amber)',
  ensemble:    'var(--green)',
}

const METRIC_LABELS = { accuracy: 'Accuracy', f1: 'F1 Score', precision: 'Precision', recall: 'Recall' }

export default function ModelComparison({ allModels, currentText }) {
  if (!allModels) return null

  const entries = Object.entries(allModels)

  const radarData = ['Accuracy', 'F1', 'Precision', 'Recall'].map(metric => {
    const row = { metric }
    entries.forEach(([key, m]) => {
      const val = metric === 'Accuracy' ? m.accuracy : m[metric.toLowerCase()] * 100
      row[m.name] = parseFloat(val.toFixed(1))
    })
    return row
  })

  return (
    <div style={{ animation:'fadeUp 0.4s ease 0.1s both' }}>
      {/* Current prediction per model */}
      <div style={{
        fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)',
        letterSpacing:'0.08em', marginBottom:10
      }}>
        PREDICTION COMPARISON
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:6, marginBottom:20 }}>
        {entries.map(([key, m]) => {
          const isSpam = m.label === 'spam'
          const color  = isSpam ? 'var(--red)' : 'var(--green)'
          const modelColor = MODEL_COLORS[key]
          return (
            <div key={key} style={{
              display:'flex', alignItems:'center', gap:12,
              background:'var(--bg3)', border:'1px solid var(--border)',
              borderRadius:'var(--radius)', padding:'10px 14px',
              borderLeft:`3px solid ${modelColor}`
            }}>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:'var(--mono)', fontSize:12, color:'var(--text)', fontWeight:600 }}>{m.name}</div>
                <div style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)', marginTop:2 }}>
                  acc {m.accuracy}% · f1 {m.f1}
                </div>
              </div>
              <div style={{
                fontFamily:'var(--mono)', fontSize:11, fontWeight:700,
                color, background: isSpam ? 'var(--red-dim)' : 'var(--green-dim)',
                borderRadius:4, padding:'3px 10px',
                border:`1px solid ${isSpam ? 'rgba(255,71,87,0.25)':'rgba(46,204,113,0.2)'}`
              }}>
                {m.label.toUpperCase()} {m.score}%
              </div>
            </div>
          )
        })}
      </div>

      {/* Metrics bars */}
      <div style={{
        fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)',
        letterSpacing:'0.08em', marginBottom:10
      }}>
        MODEL METRICS
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:20 }}>
        {entries.map(([key, m]) => {
          const mc = MODEL_COLORS[key]
          return (
            <div key={key}>
              <div style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--text-dim)', marginBottom:6, display:'flex', justifyContent:'space-between' }}>
                <span style={{ color: mc, fontWeight:600 }}>{m.name}</span>
                <span>{m.accuracy}% accuracy</span>
              </div>
              {Object.entries(METRIC_LABELS).map(([metric, label]) => {
                const val = metric === 'accuracy' ? m.accuracy : m[metric] * 100
                return (
                  <div key={metric} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                    <span style={{ fontFamily:'var(--mono)', fontSize:9, color:'var(--text-mute)', width:60, letterSpacing:'0.05em' }}>{label.toUpperCase()}</span>
                    <div style={{ flex:1, height:3, background:'var(--bg)', borderRadius:2, overflow:'hidden' }}>
                      <div style={{
                        height:'100%', borderRadius:2,
                        background: mc, opacity:0.7,
                        width:`${val}%`,
                        transition:'width 0.8s cubic-bezier(0.4,0,0.2,1)'
                      }}/>
                    </div>
                    <span style={{ fontFamily:'var(--mono)', fontSize:9, color:'var(--text-dim)', width:38, textAlign:'right' }}>
                      {val.toFixed(1)}%
                    </span>
                  </div>
                )
              })}
            </div>
          )
        })}
      </div>

      {/* Radar chart */}
      <div style={{
        fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)',
        letterSpacing:'0.08em', marginBottom:8
      }}>
        RADAR COMPARISON
      </div>
      <div style={{ height:200 }}>
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={radarData} outerRadius={70}>
            <PolarGrid stroke="var(--border)" />
            <PolarAngleAxis dataKey="metric" tick={{ fontFamily:'var(--mono)', fontSize:10, fill:'var(--text-mute)' }} />
            <Tooltip
              contentStyle={{ background:'var(--panel)', border:'1px solid var(--border)', borderRadius:6, fontFamily:'var(--mono)', fontSize:11 }}
              itemStyle={{ color:'var(--text)' }}
              labelStyle={{ color:'var(--text-dim)' }}
            />
            {entries.map(([key, m]) => (
              <Radar
                key={key}
                name={m.name}
                dataKey={m.name}
                stroke={MODEL_COLORS[key]}
                fill={MODEL_COLORS[key]}
                fillOpacity={0.12}
                strokeWidth={1.5}
              />
            ))}
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

import React from 'react'

export default function HighlightPanel({ highlights, text }) {
  if (!highlights || highlights.length === 0) return null

  // Build highlighted text by marking matched words
  const renderHighlightedText = () => {
    if (!text) return null
    let remaining = text
    const parts = []
    let key = 0

    // Simple word-level highlighting
    const spamWords = highlights.filter(h => h.direction === 'spam').map(h => h.word)
    const hamWords  = highlights.filter(h => h.direction === 'ham').map(h => h.word)

    const allWords = [...new Set([...spamWords, ...hamWords])]
    const pattern = allWords.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')

    if (!pattern) return <span style={{ fontFamily:'var(--mono)', fontSize:13, lineHeight:1.8, color:'var(--text-dim)' }}>{text}</span>

    const regex = new RegExp(`(${pattern})`, 'gi')
    const segments = text.split(regex)

    return (
      <span style={{ fontFamily:'var(--mono)', fontSize:13, lineHeight:2 }}>
        {segments.map((seg, i) => {
          const lower = seg.toLowerCase()
          const isSpam = spamWords.some(w => w.toLowerCase() === lower)
          const isHam  = hamWords.some(w => w.toLowerCase() === lower)
          if (isSpam) return (
            <mark key={i} style={{
              background:'rgba(255,71,87,0.22)', color:'var(--red)',
              borderRadius:3, padding:'1px 3px',
              border:'1px solid rgba(255,71,87,0.3)'
            }}>{seg}</mark>
          )
          if (isHam) return (
            <mark key={i} style={{
              background:'rgba(46,204,113,0.18)', color:'var(--green)',
              borderRadius:3, padding:'1px 3px',
              border:'1px solid rgba(46,204,113,0.25)'
            }}>{seg}</mark>
          )
          return <span key={i} style={{ color:'var(--text-dim)' }}>{seg}</span>
        })}
      </span>
    )
  }

  return (
    <div style={{ animation:'fadeUp 0.4s ease 0.3s both' }}>
      {/* Highlighted message */}
      <div style={{
        background:'var(--bg3)', border:'1px solid var(--border)',
        borderRadius:'var(--radius-lg)', padding:'14px 16px', marginBottom:16,
        lineHeight:2
      }}>
        {renderHighlightedText()}
      </div>

      {/* Feature importance bars */}
      <div style={{
        fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)',
        letterSpacing:'0.08em', marginBottom:10
      }}>
        FEATURE IMPORTANCE
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
        {highlights.map((h, i) => {
          const isSpam = h.direction === 'spam'
          const color  = isSpam ? 'var(--red)' : 'var(--green)'
          const pct    = Math.min(100, h.weight * 100)
          return (
            <div key={i} style={{ animation:`fadeUp 0.3s ease ${i*0.05}s both` }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{
                    fontFamily:'var(--mono)', fontSize:11,
                    background: isSpam ? 'var(--red-dim)' : 'var(--green-dim)',
                    color, borderRadius:3, padding:'1px 6px',
                    border:`1px solid ${isSpam ? 'rgba(255,71,87,0.25)':'rgba(46,204,113,0.2)'}`,
                    fontWeight:600
                  }}>{h.word}</span>
                  <span style={{ fontSize:11, color:'var(--text-mute)' }}>{h.reason}</span>
                </div>
                <span style={{ fontFamily:'var(--mono)', fontSize:11, color, fontWeight:600 }}>
                  {isSpam ? '+' : '-'}{(h.weight).toFixed(2)}
                </span>
              </div>
              <div style={{ height:4, background:'var(--bg)', borderRadius:2, overflow:'hidden', border:'1px solid var(--border)' }}>
                <div style={{
                  height:'100%', borderRadius:2,
                  background: color,
                  width:`${pct}%`,
                  transition:`width 0.6s cubic-bezier(0.4,0,0.2,1) ${i*0.05}s`,
                  opacity:0.8
                }}/>
              </div>
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div style={{ display:'flex', gap:16, marginTop:14 }}>
        {[['var(--red)', 'Spam indicator'], ['var(--green)', 'Legitimate indicator']].map(([c, l]) => (
          <div key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
            <div style={{ width:8, height:8, borderRadius:2, background:c }}/>
            <span style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)' }}>{l}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import { ShieldAlert, ShieldCheck, Zap } from 'lucide-react'

function AnimatedScore({ target }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let start = 0
    const step = target / 30
    const timer = setInterval(() => {
      start += step
      if (start >= target) { setDisplay(target); clearInterval(timer) }
      else setDisplay(Math.round(start))
    }, 16)
    return () => clearInterval(timer)
  }, [target])
  return <>{display}</>
}

export default function VerdictPanel({ result, loading }) {
  if (loading) {
    return (
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:16, padding:'48px 0', animation:'fadeIn 0.3s ease' }}>
        <div style={{ display:'flex', gap:6 }}>
          {[0,1,2].map(i => (
            <div key={i} style={{
              width:10, height:10, borderRadius:'50%', background:'var(--blue)',
              animation:'blink 1s ease-in-out infinite', animationDelay:`${i*0.2}s`
            }}/>
          ))}
        </div>
        <span style={{ fontFamily:'var(--mono)', fontSize:12, color:'var(--text-dim)', letterSpacing:'0.1em' }}>
          SCANNING MESSAGE...
        </span>
      </div>
    )
  }

  if (!result) {
    return (
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:12, padding:'48px 0', opacity:0.4 }}>
        <div style={{ fontSize:40 }}>🛡️</div>
        <span style={{ fontFamily:'var(--mono)', fontSize:12, color:'var(--text-dim)', letterSpacing:'0.08em' }}>
          AWAITING INPUT
        </span>
      </div>
    )
  }

  const isSpam = result.label === 'spam'
  const color  = isSpam ? 'var(--red)' : 'var(--green)'
  const dimBg  = isSpam ? 'var(--red-dim)' : 'var(--green-dim)'
  const anim   = isSpam ? 'pulse-red 2s ease-in-out infinite' : 'pulse-green 2s ease-in-out infinite'
  const Icon   = isSpam ? ShieldAlert : ShieldCheck
  const label  = isSpam ? 'SPAM DETECTED' : 'LEGITIMATE'

  return (
    <div style={{ animation:'fadeUp 0.4s ease', display:'flex', flexDirection:'column', alignItems:'center', gap:20, padding:'32px 0 24px' }}>
      {/* Icon */}
      <div style={{
        width:72, height:72, borderRadius:'50%',
        background: dimBg,
        border: `1.5px solid ${color}`,
        display:'flex', alignItems:'center', justifyContent:'center',
        animation: anim,
      }}>
        <Icon size={32} color={color} strokeWidth={1.5}/>
      </div>

      {/* Verdict label */}
      <div style={{
        fontFamily:'var(--mono)', fontSize:22, fontWeight:600,
        color, letterSpacing:'0.12em',
        animation:'count-up 0.4s ease 0.1s both'
      }}>
        {label}
      </div>

      {/* Score gauge */}
      <div style={{ width:'100%', animation:'fadeUp 0.4s ease 0.15s both' }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
          <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--text-dim)', letterSpacing:'0.06em' }}>SPAM PROBABILITY</span>
          <span style={{ fontFamily:'var(--mono)', fontSize:11, color, fontWeight:600 }}>
            <AnimatedScore target={result.score}/>%
          </span>
        </div>
        <div style={{ height:6, background:'var(--bg)', borderRadius:3, overflow:'hidden', border:'1px solid var(--border)' }}>
          <div style={{
            height:'100%', borderRadius:3,
            background: `linear-gradient(90deg, ${isSpam ? '#FF4757' : '#2ECC71'}, ${isSpam ? '#FF6B81' : '#55EFC4'})`,
            width:`${result.score}%`,
            transition:'width 0.8s cubic-bezier(0.4,0,0.2,1)',
            boxShadow:`0 0 8px ${color}55`
          }}/>
        </div>
      </div>

      {/* Meta chips */}
      <div style={{ display:'flex', gap:10, flexWrap:'wrap', justifyContent:'center', animation:'fadeUp 0.4s ease 0.2s both' }}>
        {[
          { label:'CONFIDENCE', val:`${result.confidence}%` },
          { label:'MODEL', val: result.model_used },
          { label:'LATENCY', val:`${result.inference_ms}ms`, icon: Zap },
        ].map(chip => (
          <div key={chip.label} style={{
            display:'flex', alignItems:'center', gap:5,
            background:'var(--bg3)', border:'1px solid var(--border)',
            borderRadius:4, padding:'5px 10px',
          }}>
            {chip.icon && <chip.icon size={11} color="var(--amber)"/>}
            <span style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text-dim)', letterSpacing:'0.06em' }}>{chip.label}</span>
            <span style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text)', fontWeight:600 }}>{chip.val}</span>
          </div>
        ))}
      </div>

      {/* Stats row */}
      {result.stats && (
        <div style={{
          display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, width:'100%',
          animation:'fadeUp 0.4s ease 0.25s both'
        }}>
          {[
            { k:'WORDS', v: result.stats.word_count },
            { k:'CAPS %', v: `${result.stats.caps_ratio}%` },
            { k:'SPAM WORDS', v: result.stats.spam_word_count },
            { k:'SENTENCES', v: result.stats.sentence_count },
            { k:'EXCLAMATIONS', v: result.stats.exclamation_count },
            { k:'URLS', v: result.stats.url_count },
          ].map(s => (
            <div key={s.k} style={{
              background:'var(--bg3)', border:'1px solid var(--border)',
              borderRadius:'var(--radius)', padding:'8px 10px', textAlign:'center'
            }}>
              <div style={{ fontFamily:'var(--mono)', fontSize:10, color:'var(--text-mute)', letterSpacing:'0.05em', marginBottom:3 }}>{s.k}</div>
              <div style={{ fontFamily:'var(--mono)', fontSize:15, fontWeight:600, color:'var(--text)' }}>{s.v}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
